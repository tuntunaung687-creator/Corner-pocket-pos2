CORNER POCKET POS - ANDROID PROJECT (15 TABLES)

ဒီ ZIP က Android APK တည်ဆောက်ရန် Project Source ဖြစ်သည်။ APK ဖိုင်ကိုယ်တိုင် မဟုတ်သေးပါ။

ပါဝင်သည်
- Android WebView App shell
- POS စနစ်ကို app ထဲတွင် offline asset အဖြစ် ထည့်ထားသည်
- 15 ခုံ
- Internet permission မထည့်ထားပါ
- GitHub Actions workflow ဖြင့် APK build လုပ်နိုင်ရန် build-apk.yml ပါဝင်သည်

ဖုန်းတစ်လုံးတည်းဖြင့် APK build လုပ်ရန် (GitHub အသုံးပြုနည်း)
1. ZIP ကို ဖြည်ပါ။
2. GitHub တွင် repository အသစ်တစ်ခု ဖွင့်ပါ။
3. Project ဖိုင်များအားလုံးကို repository ထဲ upload လုပ်ပါ (folder structure မပျက်စေရ)။
4. GitHub repository > Actions ကိုဝင်ပါ။
5. "Build Corner Pocket APK" workflow ကိုရွေးပြီး Run workflow နှိပ်ပါ။
6. Build ပြီးလျှင် workflow run အောက်ဆုံး Artifacts မှ Corner-Pocket-POS-debug ကို download လုပ်ပါ။
7. ZIP ဖြည်ပြီး app-debug.apk ကို Android Tablet တွင် install လုပ်ပါ။ Unknown apps install ခွင့် တောင်းလျှင် ခွင့်ပြုပါ။

မူလ Owner PIN: 1234

သတိပြုရန်
- ဒါက ပထမဆုံး Android APK wrapper project ဖြစ်ပြီး Debug APK ဖြစ်သည်။
- အက်ပ်ထဲရှိ local data ကို app data clear/uninstall လုပ်လျှင် ပျောက်နိုင်သည်။ POS Settings မှ Backup ထုတ်ထားပါ။
- လက်ရှိ build သည် စမ်းသပ်ရန်ဖြစ်သည်။ Staff login, immutable audit log, manager/owner role separation နှင့် ပြည့်စုံသော receipt printer integration မပါသေးပါ။
- ခုံပိတ်ခြင်းကို PIN ဖြင့်ကာကွယ်ထားသော်လည်း production-grade security မဟုတ်သေးပါ။
